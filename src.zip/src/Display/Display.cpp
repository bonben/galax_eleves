#include "Display.hpp"

Display
::Display(Particles& particles)
: particles(particles)
{
}

Display::~Display()
{
}
