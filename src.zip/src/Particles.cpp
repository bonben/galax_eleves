#include "Particles.hpp"

Particles::
Particles(const int n_particles)
: x(n_particles),
  y(n_particles),
  z(n_particles)
{
}